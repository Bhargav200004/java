package javalloop;

public class pattern9 {
    public static void main(String arg[]) {
       int N=4;
       ///for(int i=0;i<N;i++){
       
       //}
       if (N % 2==0)
         System.out.println("even");
         else
         System.out.println("odd");
    }
    
}
