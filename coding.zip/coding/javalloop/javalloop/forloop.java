package javalloop;
public class forloop {
    static void main(String arg[]){
    
    while(true)
    System.out.println("i");
    }
}