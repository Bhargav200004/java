package javalloop;

public class experimental {
    public static void main(String arg[]){
        int L ,B , W , H , R;
        L=10;
        B=5;
        W=6;
        H=8;
        R=7;
        //A=B*L*1/2;
        //D=L*W;
        //C=(R*R)*22/7;

        System.out.println((B*L*1/2)+" "+(L*W)+" "+((R*R)*22/7) );
    }
    
}
