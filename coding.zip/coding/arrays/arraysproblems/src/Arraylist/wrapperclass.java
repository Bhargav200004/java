package Arraylist;

public class wrapperclass {
    public static void main(String[] args) {
        //wrapper class
        //1.integer
        Integer i=Integer.valueOf(5);
        System.out.println(i);

        //2.float
        Float f=Float.valueOf(0.5f);
        System.out.println(f);


    }
}
