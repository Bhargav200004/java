public class program10 {
    public static void main(String[] args) {


    }
}
